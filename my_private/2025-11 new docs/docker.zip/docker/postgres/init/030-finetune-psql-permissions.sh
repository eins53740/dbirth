psql --username "$POSTGRES_USER" --dbname "uns_metadata" -v ON_ERROR_STOP=1 <<'SQL'
-- Lock down PUBLIC (optional but recommended)
REVOKE CONNECT ON DATABASE uns_metadata FROM PUBLIC;
REVOKE ALL ON SCHEMA uns_meta FROM PUBLIC;

-- App: database-level permissions
GRANT CONNECT, TEMP ON DATABASE uns_metadata TO uns_meta_app;

-- App: schema-level permissions
GRANT USAGE ON SCHEMA uns_meta TO uns_meta_app;

-- App: read/write on ALL existing objects
GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES, TRIGGER ON ALL TABLES    IN SCHEMA uns_meta TO uns_meta_app;
GRANT USAGE, SELECT, UPDATE                         ON ALL SEQUENCES IN SCHEMA uns_meta TO uns_meta_app;
GRANT EXECUTE                                       ON ALL FUNCTIONS IN SCHEMA uns_meta TO uns_meta_app;

-- App: defaults for FUTURE objects created by the owner
ALTER DEFAULT PRIVILEGES FOR ROLE uns_meta_owner IN SCHEMA uns_meta
  GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES, TRIGGER ON TABLES TO uns_meta_app;
ALTER DEFAULT PRIVILEGES FOR ROLE uns_meta_owner IN SCHEMA uns_meta
  GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO uns_meta_app;
ALTER DEFAULT PRIVILEGES FOR ROLE uns_meta_owner IN SCHEMA uns_meta
  GRANT EXECUTE ON FUNCTIONS TO uns_meta_app;

-- If the app should ALSO create tables/functions in this schema, enable CREATE and set defaults for objects the app creates:
-- GRANT CREATE ON SCHEMA uns_meta TO uns_meta_app;
-- ALTER DEFAULT PRIVILEGES FOR ROLE uns_meta_app IN SCHEMA uns_meta
--   GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES, TRIGGER ON TABLES TO uns_meta_app;
-- ALTER DEFAULT PRIVILEGES FOR ROLE uns_meta_app IN SCHEMA uns_meta
--   GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO uns_meta_app;
-- ALTER DEFAULT PRIVILEGES FOR ROLE uns_meta_app IN SCHEMA uns_meta
--   GRANT EXECUTE ON FUNCTIONS TO uns_meta_app;

-- CDC typically only needs CONNECT; keep REPLICATION at role level
GRANT CONNECT ON DATABASE uns_metadata TO uns_meta_cdc;
SQL

